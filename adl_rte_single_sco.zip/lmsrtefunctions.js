/*******************************************************************************
**
** Filename:  lmsrtefunctions.js
**
** File Description:  This file contains several javascript variable definitions
**                   and functions that are used commonly by all of the SCO HTML
**                   files in the LMS Runtime Environment Conformance Test.  It
**                   is intended to be included in each SCO HTML file.
**
** Author: ADL Technical Team
**
** Contract Number:
** Company Name: Concurrent Technologies Corporation
**
** 
** Design Issues:   None
** Implementation Issues:  None

** Known Problems: None
** Side Effects:  None
**
** References:
**
**
***************************************************************************
**
** Advanced Distributed Learning Co-Laboratory (ADL Co-Lab) grants you
** ("Licensee") a non-exclusive, royalty free, license to use, modify and
** redistribute this software in source and binary code form, provided that
** i) this copyright notice and license appear on all copies of the software;
** and ii) Licensee does not utilize the software in a manner which is
** disparaging to ADL Co-Lab.
**
** This software is provided "AS IS," without a warranty of any kind.  ALL
** EXPRESS OR IMPLIED CONDITIONS, REPRESENTATIONS AND WARRANTIES, INCLUDING
** ANY IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
** OR NON-INFRINGEMENT, ARE HEREBY EXCLUDED.  ADL Co-Lab AND ITS LICENSORS
** SHALL NOT BE LIABLE FOR ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF
** USING, MODIFYING OR DISTRIBUTING THE SOFTWARE OR ITS DERIVATIVES.  IN NO
** EVENT WILL ADL Co-Lab OR ITS LICENSORS BE LIABLE FOR ANY LOST REVENUE,
** PROFIT OR DATA, OR FOR DIRECT, INDIRECT, SPECIAL, CONSEQUENTIAL,
** INCIDENTAL OR PUNITIVE DAMAGES, HOWEVER CAUSED AND REGARDLESS OF THE
** THEORY OF LIABILITY, ARISING OUT OF THE USE OF OR INABILITY TO USE
** SOFTWARE, EVEN IF ADL Co-Lab HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH
** DAMAGES.
**
** Date Changed   Author            Reason for Changes
** ------------   ----------------  -------------------------------------------
**
** 07/11/2001     Jeff Falls        PT 966: Course 1/SCOs 5 and 6 reported "red"
**                                  failure messages for optional data model
**                                  elements returning a "404" Not Implemented
**                                  string.  These are now reported as "yellow"
**                                  warning message if the data model element is
**                                  optional.  Otherwise, it is a mandatory
**                                  element and the "red" failure message is
**                                  reported.
**
** 08/27/2001     J. Falls          Changed "can not" to "cannot".
**
*******************************************************************************/

// Define exception/error codes
var _NoError = 0;
var _GeneralException = "101";
var _InvalidArgumentError = "201";
var _ElementCannotHaveChildren = "202";
var _ElementIsNotAnArray = "203";
var _NotInitialized = "301";
var _NotImplementedError = "401";
var _InvalidSetValue = "402";
var _ElementIsReadOnly = "403";
var _ElementIsWriteOnly = "404";
var _IncorrectDataType = "405";

var errorMatrix = new Array(12);
errorMatrix[0] = new Array("0", "No error");
errorMatrix[1] = new Array("101", "General Exception");
errorMatrix[2] = new Array("201", "Invalid argument error");
errorMatrix[3] = new Array("202", "Element cannot have children");
errorMatrix[4] = new Array("203", "Element not an array - Cannot have count");
errorMatrix[5] = new Array("301", "Not initialized");
errorMatrix[6] = new Array("401", "Not implemented error");
errorMatrix[7] = new Array("402", "Invalid set value, element is a keyword");
errorMatrix[8] = new Array("403", "Element is read only");
errorMatrix[9] = new Array("404", "Element is write only");
errorMatrix[10] = new Array("405", "Incorrect Data Type");
errorMatrix[11] = new Array("", ""); 


// page scoped variable definitions
var apiHandle = null;
var API = null;
var findAPITries = 0;

// Data Model Conformance State values
var someOptional = false;
var allOptional = true;
var allMandatory = true;


var _Debug = false;  // set this to false to turn debugging off
                     // to get rid of those annoying alert boxes.

//define the log message type constants  
var _INFO = 0;              //  0 = informational (diagnostic, trace, etc.)
var _WARNING = 1;           //  1 = warning
var _PASSED = 2;            //  2 = conformance check passed
var _FAILED = 3;            //  3 = conformance check failure
var _TERMINATE = 4;         //  4 = test suite termination due to nonconformance or error
var _CONFORMANT = 5;        //  5 = subject is found to be conformant
var _OTHER = 9;             //  other

//var _STATUS_CONFORMANT = "conformant";
//var _STATUS_NONCONFORMANT = "non";


// local variable definitions

// we'll track the status of the test using a state variable called scoStatus
// This is set by each SCO as it progresses through the test.  
var scoStatus = null;

var cmiBooleanFalse = "false";
var cmiBooleanTrue = "true";

// facade for test suite applet
function LMSRTEApplet_facade() {
    function dummy() {}
    function returnTrue() { return cmiBooleanTrue; }
    this.writeLogEntry = dummy;
    this.setApiConformant = dummy;
    this.setCurrentSCO = dummy;
    this.setCurrentSCOStatus = dummy;
    this.setSessionCompleted = dummy;
    this.verifyElementType = returnTrue;
    this.setLaunchConformant = dummy;
    if (navigator.appName == "Netscape")
        teststatus = {};
} 

function determineSCORMVersion(status)
{
    if (status == "0" || status == "1") {
        cmiBooleanFalse = "0";
        cmiBooleanTrue = "1";
    } if (status == "true" || status == "false") {
        cmiBooleanFalse = "false";
        cmiBooleanTrue = "true";
    }
}

function isScorm_10() 
{
    return cmiBooleanTrue == "1";
}
function isScorm_11()
{
    return cmiBooleanTrue == "true";
}

lmsRTEApplet = new LMSRTEApplet_facade();


/*******************************************************************************
**
** Function: writeLogEntry(type, msg)
** Inputs:  type - must be one of the following (constants defined above:
**                      _INFO    - informational (diagnostic, trace, etc.)
**                      _WARNING - warning
**                      _PASSED  - conformance check passed
**                      _FAILED  - conformance check failure
**                      _TERMINATE - terminating due to nonconformance or error
**                      _CONFORMANT - subject is  conformant
**                      _OTHER      - display no icon and use default font.
**          msg - string containing log message
**
** Return:  None
**
**  Description: This function displays a test suite log message.  Note: the
**  LogWriterApplet must be present in the HTML file that this script is 
**  included in and be identified by the logWriter object id.
**
*******************************************************************************/
function writeLogEntry(type, msg)
{
   lmsRTEApplet.writeLogEntry(type, msg);
}


/******************************************************************************
**
** Function getAPIHandle()
** Inputs:  None
** Return:  value contained by APIHandle
**
** Description:
** Returns the handle to API object if it was previously set,
** otherwise it returns null
**
*******************************************************************************/
function getAPIHandle()
{
   if (apiHandle == null)
   {
      apiHandle = getAPI();
      if(apiHandle == null)
      {
         writeLogEntry(_FAILED, "Unable to locate LMS's API Adapter - Test Failed");
         lmsRTEApplet.setAPIConformant(false);
         terminateTest();
      }
   }

   return apiHandle;
}

/*******************************************************************************
**
** Function: setAPIHandle(api)
** Inputs:  api (may be null)
** Return:  None
**
**  Description: call this function from the file that includes tsapiwrapper.js 
** AU01 will pass in an api object and the other SCOs will pass in null to allow 
** this function to find it.
**
*******************************************************************************/
function setAPIHandle(api)
{

   if (_Debug)
   {
      alert("in setAPIHandle()");
   }

   if (api == null)
   {

      apiHandle = getAPI();
      if (apiHandle == null)
      {
         handleAPINotFound();
      }
   }
   else
   {
      apiHandle = api;
   }
}


/*******************************************************************************
**
** Function: doLMSInitialize()
** Inputs:  None
** Return:  CMIBoolean true if the initialization was successful, or
**          CMIBoolean false if the initialization failed.
**
** Description:
** Initialize communication with LMS by calling the LMSInitialize
** function which will be implemented by the LMS.
**
*******************************************************************************/
function doLMSInitialize()
{
   writeLogEntry(_INFO, "Attempting to call LMSInitialize function");

   var api = getAPIHandle();
   if (api == null)
   {
      alert("Unable to locate the LMS's API Implementation.\nLMSInitialize was not successful.");
      return cmiBooleanFalse;
   }

   var result = api.LMSInitialize("");
   determineSCORMVersion(result);
   if((result != cmiBooleanTrue) && (result != cmiBooleanFalse))
   {
      lmsRTEApplet.setApiConformant(false);

      logMsg = "LMSInitialize did not return a CMIBoolean value.";
      logMsg += "LMSInitialize returned: &quot;"+result+"&quot;.";
      writeLogEntry(_FAILED, logMsg);

      terminateTest();
      return;
   }
   if (result != cmiBooleanTrue)
   {
      var err = errorHandler();
      writeLogEntry(_FAILED, "LMSInitialize failed");
      lmsRTEApplet.setApiConformant(false);
      terminateTest();
   }
   else
   {
      writeLogEntry(_PASSED, "LMSInitialize completed successfully");
   }


   return result;
}
 

/*******************************************************************************
**
** Function doLMSFinish()
** Inputs:  None
** Return:  CMIBoolean true if successful
**          CMIBoolean false if failed.
**
** Description:
** Close communication with LMS by calling the LMSFinish
** function which will be implemented by the LMS
**
*******************************************************************************/
function doLMSFinish()
{

   writeLogEntry(_INFO, "Attempting to call LMSFinish function");
   
   var api = getAPIHandle();
   if (api == null)
   {
      alert("Unable to locate the LMS's API Implementation.\nLMSFinish was not successful.");
      return cmiBooleanFalse;
   }
   else
   {
      // call the LMSFinish function that should be implemented by the API

      var result = api.LMSFinish("");
      if (isScorm_11()) {
          if (result != cmiBooleanTrue)
          {
             var err = errorHandler();
          }
      } else {
         var err = errorHandler();
         result = err == _NoError ? cmiBooleanTrue : cmiBooleanFalse;
      }
   }
   
   if (result == cmiBooleanFalse)
   {
      writeLogEntry(_FAILED, "LMSFinish Failed");
      lmsRTEApplet.setApiConformant(false);
      terminateTest();
   }
   else
   {
      scoStatus = "completed";
      writeLogEntry(_PASSED, "LMSFinish completed successfully");
   }

   return result.toString();
} 

/*******************************************************************************
**
** Function terminateTest() 
** Inputs:  None
** Return:  None
**
** Description: 
** This function terminates the current test when a non-conformance 
** condition is encountered.
**
*******************************************************************************/
function terminateTest()
{
   writeLogEntry(_TERMINATE, "The Test Subject LMS is non conformant");
   teststatus.innerText = "Status:  This SCO Test Terminated.  Please view the log for details.";
   scoStatus = "terminated";
   lmsRTEApplet.setCurrentSCOStatus("terminated");
   lmsRTEApplet.setSessionCompleted(true);
}

/*******************************************************************************
**
** Function handleAPINotFound() 
** Inputs:  None
** Return:  None
**
** Description: 
** This function is called when the API object is not found, or is null when a 
** non-null value is expected.  It logs an appropriate error and terminates the 
** current test.
**
*******************************************************************************/
function handleAPINotFound()
{
   writeLogEntry(_FAILED, "Unable to locate the LMS API object");
   lmsRTEApplet.setApiConformant(false);
   terminateTest();
}

/*******************************************************************************
**
** Function isOptionalDMElement(dmElemName)
** Inputs:  dmElemName - string representing the cmi data model defined category
**          or element (e.g. cmi.core.student_id)
** Return:  false -> is a mandatory element
**          true -> is an optional element
**
** Description:
** Determines if a data model element is mandatory or optional.
**
*******************************************************************************/
function isOptionalDMElement(dmElemName)
{
   var man;

   if ( dmElemName == "cmi.core._children" || 
        dmElemName == "cmi.core.student_id" ||
        dmElemName == "cmi.core.student_name" ||
        dmElemName == "cmi.core.lesson_location" ||
        dmElemName == "cmi.core.credit" ||
        dmElemName == "cmi.core.lesson_status" ||
        dmElemName == "cmi.core.entry" ||
        dmElemName == "cmi.core.total_time" ||
        dmElemName == "cmi.core.exit" ||
        dmElemName == "cmi.core.session_time" ||
        dmElemName == "cmi.suspend_data" ||
        dmElemName == "cmi.launch_data" )
   {
      man = false;
   }
   else //it is an optional element
   {
      man = true;
   }

   return man;
}

/*******************************************************************************
**
** Function doLMSGetValue(name)
** Inputs:  name - string representing the cmi data model defined category or
**             element (e.g. cmi.core.student_id)
** Return:  The value presently assigned by the LMS to the cmi data model
**       element defined by the element or category identified by the name
**       input value.
**
** Description:
** Wraps the call to the LMS LMSGetValue method
**
*******************************************************************************/
function doLMSGetValue(name)
{
   var isOptional = isOptionalDMElement(name);
   var logMsg = "LMSGetValue(" + name + ")";
   
   var api = getAPIHandle();
   if (api == null)
   {
      alert("Unable to locate the LMS's API Implementation.\nLMSGetValue was not successful.");
      return "";
   }
   else
   {
      var value = api.LMSGetValue(name);
      var errCode = api.LMSGetLastError().toString();
      
      if (errCode != _NoError)
      {
         if ( errCode == _NotImplementedError)
         {
            //display the warning or failure
            if ( isOptional )
            {
               logMsg += " for <b>Optional</b> element resulted in the " +
                         "following error: " + doLMSGetErrorString(errCode);
               writeLogEntry(_WARNING, logMsg); // KEEP GOING! - Not necessarily non-conformant.
               return "";
            }
            else
            {
               logMsg += " for <b>Mandatory</b> element resulted in the " +
                         "following error: " + doLMSGetErrorString(errCode);
               writeLogEntry(_FAILED, logMsg); // KEEP GOING! - Not necessarily non-conformant.
               return "";
            }
         }
      }
      else
      {
         logMsg += " returned";
         if ( lmsRTEApplet.verifyElementType(name, value) != cmiBooleanTrue)
         {
            logMsg += " a value that is NOT of the correct datatype:  ";
            logMsg += "&quot;" + value + "&quot;";
            writeLogEntry(_FAILED, logMsg);
            return "";
         }
         else
         {
            logMsg += ": " + value;
            writeLogEntry(_PASSED, logMsg);
            return value.toString();
         }
      }
   }
}


/*******************************************************************************
**
** Function doLMSSetValue(name, value)
** Inputs:  name -string representing the data model defined category or element
**          value -the value that the named element or category will be assigned
** Return:  CMIBoolean true if successful
**          CMIBoolean false if failed.
**
** Description:
** Wraps the call to the LMS LMSSetValue function
**
*******************************************************************************/
function doLMSSetValue(name, value)
{
   var logMsg =  "LMSSetValue(" +name+ ", &quot;"+ value+"&quot;)";

   var api = getAPIHandle();
   if (api == null)
   {
      alert("Unable to locate the LMS's API Implementation.\nLMSSetValue was not successful.");
      return;
   }
   else
   {
      var result = api.LMSSetValue(name, value);
      if (isScorm_10()) {
         result = api.LMSGetLastError() == _NoError ? cmiBooleanTrue : cmiBooleanFalse;
      }
      if (result != cmiBooleanTrue)
      {
         
         var errCode = api.LMSGetLastError();
         logMsg += " resulted in the following error: ";
         logMsg += apiHandle.LMSGetErrorString(errCode);
         
         writeLogEntry(_FAILED, logMsg);
      }
      else
      {
         logMsg += " succeeded";
         writeLogEntry(_PASSED, logMsg);
      }   
   }

   return;
}

/*******************************************************************************
**
** Function doLMSCommit()
** Inputs:  None
** Return:  None
**
** Description:
** Call the LMSCommit function 
**
*******************************************************************************/
function doLMSCommit()
{
   writeLogEntry(_INFO, "Attempting to call LMSCommit function");
      
   var api = getAPIHandle();
   if (api == null)
   {
      // if this happens - the test will already be terminating...
      alert("Unable to locate the LMS's API Implementation.\nLMSCommit was not successful.");
      return cmiBooleanFalse;
   }
   else
   {
      var result = api.LMSCommit("");
      if (isScorm_10()) {
         result = api.LMSGetLastError() == _NoError ? cmiBooleanTrue : cmiBooleanFalse;
      }
      if (result != cmiBooleanTrue)
      {
         var err = errorHandler();
         writeLogEntry(_FAILED, "LMSCommit Failed");
         lmsRTEApplet.setApiConformant(false);

         terminateTest();
      }
      else
      {
         writeLogEntry(_PASSED, "LMSCommit completed successfully");
      }
   }

   return result.toString();
}
 

/*******************************************************************************
**
** Function doLMSGetLastError()
** Inputs:  None
** Return:  The error code that was set by the last LMS function call
**
** Description:
** Call the LMSGetLastError function 
**
*******************************************************************************/
function doLMSGetLastError()
{
   var api = getAPIHandle();
   if (api == null)
   {
      alert("Unable to locate the LMS's API Implementation.\nLMSGetLastError was not successful.");
      //since we can't get the error code from the LMS, return a general error
      return _GeneralError;
   }

   return api.LMSGetLastError().toString();
} 

/*******************************************************************************
**
** Function doLMSGetErrorString(errorCode)
** Inputs:  errorCode - Error Code
** Return:  The textual description that corresponds to the input error code
**
** Description:
** Call the LMSGetErrorString function 
**
********************************************************************************/
function doLMSGetErrorString(errorCode)
{
   var api = getAPIHandle();
   if (api == null)
   {
      lmsRTEApplet.setApiConformant(false);
      alert("Unable to locate the LMS's API Implementation.\nLMSGetErrorString was not successful.");
   }

   var errorString = api.LMSGetErrorString(errorCode).toString();
   // validate that the error string is valid for the error code...
   if(validateErrorString(errorCode, errorString) != true)
   {
      // generate a warning - not a strict conformance requirement...
      var msg = "The LMS returned an invalid error string for error code: ";
      msg += errorCode;
      msg += "<BR>The LMS returned:<BR> ";
      if(errorString == "")
      {
         errorString = "<i><blank></i>";
      }
      msg += errorString;
      msg += "<BR>The LMS should have returned:<BR> ";
      msg += getCorrectErrorString(errorCode);
      
      writeLogEntry(_WARNING, msg);

   }
   return errorString;
}


/*******************************************************************************
**
** Function getCorrectErrorCode(errorCode)
** Inputs:  errorCode - Error Code String
** Return:  Error String corresponding to the errorCode if found, otherwise ""
**
** Description:
** Returns the Error String corresponding to the errorCode if found, otherwise,
** if the code is invalid, an empty string ("") is returned.
**
********************************************************************************/
function getCorrectErrorString(errorCode)
{

   for(emIdx=0;emIdx<11;emIdx++)
   {
      if(errorMatrix[emIdx][0] == errorCode)
      {
         return errorMatrix[emIdx][1];
      }
   }
   return "";
}


/*******************************************************************************
**
** Function validateErrorCode(errorCode)
** Inputs:  errorCode - Error Code String to validate
** Return:  true if code is valid, otherwise false
**
** Description:
** Determine if the errorCode parameter is a valid API Error Code 
**
********************************************************************************/
function validateErrorCode(errorCode)
{
   for(emIdx=0;emIdx<11;emIdx++)
   {
      if(errorMatrix[emIdx][0] == errorCode)
      {
         return true;
      }
   }

   return false;
}


/*******************************************************************************
**
** Function validateErrorString(errorCode, errorString)
** Inputs:  errorCode - Error Code String to use for validating error string
**          errorString - Error String to validate
** Return:  true if errorString is valid, otherwise false
**
** Description:
** Determine if the errorCode parameter is a valid API Error Code 
**
********************************************************************************/
function validateErrorString(errorCode, errorString)
{
   for(emIdx=0;emIdx<12;emIdx++)
   {
      if(errorMatrix[emIdx][0] == errorCode)
      {
         if(errorString.toLowerCase() == errorMatrix[emIdx][1].toLowerCase())
         {
            return true;
         }
      }
   }

   return false;
}



/*******************************************************************************
**
** Function doLMSGetDiagnostic(errorCode)
** Inputs:  errorCode - Error Code(integer format), or null
** Return:  The vendor specific textual description that corresponds to the 
**          input error code
**
** Description:
** Call the LMSGetDiagnostic function
**
*******************************************************************************/
function doLMSGetDiagnostic(errorCode)
{
   var api = getAPIHandle();
   if (api == null)
   {
      alert("Unable to locate the LMS's API Implementation.\nLMSGetDiagnostic was not successful.");
      lmsRTEApplet.setApiConformant(false);

   }

   return api.LMSGetDiagnostic(errorCode).toString();
} 


/*******************************************************************************
**
** Function errorHandler()
** Inputs:  None
** Return:  The current value of the LMS Error Code
**
** Description:
** Determines if an error was encountered by the previous API call
** and if so, displays a message to the user.  If the error code
** has associated text it is displayed.  
**
** Side Effects: Displays an alert window with the appropriate error information
**
*******************************************************************************/
function errorHandler() 
{
   if (_Debug)
   {
      alert("in errorHandler()");
   }
   // check for errors caused by or from the LMS
   
   // Note:  apiHandle should never be null at this point, but check to be sure
   if (apiHandle != null)
   {
      var errCode = apiHandle.LMSGetLastError();
   
      if (errCode != _NoError)
      {
         // an error was encountered so display the error description
         var errDescription = apiHandle.LMSGetErrorString(errCode);
         errDescription += "<BR>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Diagnostic:  ";
         errDescription += apiHandle.LMSGetDiagnostic(errCode);
         writeLogEntry(_FAILED, "The following error was encountered:   " + errDescription);
      }
   
      return errCode;
   }
   else
   {
      writeLogEntry( _OTHER, "Unable to determine LMS Error Code. API is unexpectedly null.  Terminating Test.");
      terminateTest();
      return _GeneralException;
   }
}


/*******************************************************************************
**
** Function findAPI(win)
** Inputs:  win - a Window Object
** Return:  If an API object is found, it's returned, otherwise null is returned
**
** Description:
** This function looks for an object named API in parent and opener windows
**
*******************************************************************************/
function findAPI(win)
{
   while ((win.API == null) && (win.parent != null) && (win.parent != win))
   {
      findAPITries++;
      // Note: 7 is an arbitrary number, but should be more than sufficient
      if (findAPITries > 7) 
      {
         alert("Error finding API -- too deeply nested.");
         return null;
      }
      
      win = win.parent;

   }
   return win.API;
}


/*******************************************************************************
**
** Function getAPI()
** Inputs:  none
** Return:  If an API object is found, it's returned, otherwise null is returned
**
** Description:
** This function looks for an object named API, first in the current window's 
** frame hierarchy and then, if necessary, in the current window's opener window
** hierarchy (if there is an opener window).
**
*******************************************************************************/
function getAPI()
{
   var theAPI = findAPI(window);
   if ((theAPI == null) && (window.opener != null) && (typeof(window.opener) != "undefined"))
   {
      theAPI = findAPI(window.opener);
   }
   if (theAPI == null)
   {
      alert("Unable to find an API adapter");
   }
   return theAPI
}


/*******************************************************************************
**
** Function isLaunchedInOrder(seq)
** Inputs:  seq - integer number specifying the sequential order the SCO is 
**                SUPPOSED to be launched in.
** Return:  boolean - false if the SCO was launched out of sequence
**                    true if the SCO was launched in sequence
**
** Description:  This function determines if an SCO was launched in the order 
**               specified by the seq input value
*******************************************************************************/
function isLaunchedInOrder(course, sco)
{
   // ignore this check because this check does not apply in this
   // use of the lesson 7 to test browser independence of API adapter
   return true;
   if (_Debug)
   {
      alert("in isLaunchedInOrder - sco is" + sco);
   }

   var counter;
    
   if(course == 1)
   {
      counter = lmsRTEApplet.getCourseOneCurrentSCOIndex();
   }
   else
   {
      counter = lmsRTEApplet.getCourseTwoCurrentSCOIndex();
   }
   
   counter++;

   if (_Debug)
   {
      alert("just got sequence counter - incremented counter is now: " + counter);
   }
   if (counter+1 != sco)
   {
      alert("This SCO was launched out of sequence!");
      return false;
   }
   else
   {
      if(course == 1)
      {
         
         lmsRTEApplet.setCourseOneCurrentSCOIndex(counter);
      }
      else
      {
         lmsRTEApplet.setCourseTwoCurrentSCOIndex(counter);
      }

      return true;
   }
}




/*******************************************************************************
**
** Function testLaunch(course, sco)
** Inputs: course - number of test course(1 or 2)
**         sco - test sco number (e.g. 1, 2, etc.)
** Return:  None
**
** Description:  This function determines if an SCO was launched correctly
*******************************************************************************/
function testLaunch(course, sco)
{

   if (_Debug)
   {
      alert("in testLaunch()");
   }
   // Verify Launch Test Criteria

   // If we get to this point, assume that the SCO has been launched by the LMS.
   
   // the LMS was able to launch at least one SCO...
   lmsRTEApplet.setLaunchConformant(true);

   writeLogEntry(_OTHER, "");
   writeLogEntry(_INFO, "              SCO 0"+sco+" has been launched.");
   
   // Is this SCO launched in the specified test sequence? 

   writeLogEntry(_INFO, "Validating SCO launch sequence.");
   if (isLaunchedInOrder(course, sco) != true)
   {
      // The SCO was launched in the wrong order
      
      var launchMessage = "This SCO was not launched in the correct sequence.\n";
      launchMessage += "Click OK if the SCO was launched automatically by the LMS.\n";
      launchMessage += "Click Cancel if the SCO was launched by the user.";

      if (confirm(launchMessage))
      {
         writeLogEntry(_FAILED, "The LMS did not launch the SCO in the appropriate sequence.");

      }
      else
      {
         // must have been operator error?
         writeLogEntry(_FAILED, "The operator did not launch the SCO in the appropriate sequence.");
      }
   }
   else
   {
      writeLogEntry(_PASSED, "The SCO has been launched in the appropriate sequence.");
      
   }

   lmsRTEApplet.setCurrentSCO(course, sco-1);
}






   /*******************************************************************************
   **
   ** Function getCMIDateToday()
   ** Inputs:  None
   ** Return:  Current Date in CMIDate format
   **
   ** Description: 
   ** This function returns the current date in CMIDate format  
   **
   *******************************************************************************/
   function getCMIDateToday()
   {

      if(_Debug)
      {
         alert("In getCMIDateToday()");
      }

      var todayDate = new Date();

      var theMonth = todayDate.getMonth();
      theMonth++;   // the month is zero based?
      if(theMonth < 10)
      {
         theMonth = "0" + theMonth;
      }

      var theDay = todayDate.getDate();
      if(theDay < 10)
      {
         theDay = "0" + theDay;
      }
      var cmiDateToday = todayDate.getYear() + "/";
      cmiDateToday += theMonth + "/";
      cmiDateToday += theDay;

      if(_Debug)
      {
         alert("Today's CMI Date is: "+ cmiDateToday);
      }

      return cmiDateToday;
   }

  /******************************************************************************
   ** Function testGetValue(name) 
   ** Inputs:  name - string representing the cmi data model defined category or 
   **                 element (e.g. cmi.core.student_id)
   ** Return:  The value presently assigned by the LMS to the cmi data model 
   **          element defined by the element or category identified by the name
   **          input value.
   **
   ** Description: 
   ** Wraps the call to the LMS LMSGetValue method
   **
   ******************************************************************************/
   function testGetValue(name, index)
   {
      
      
      if(_Debug)
      {
         alert("in testGetValue() - name is: "+ name);
      }

      // handle only the readable data model elements
      if(dataModelMatrix[index][1] == _W)
      {
         return "";
      }

      var logMsg = "LMSGetValue(" + name + ") ";

      var value;


      // assume element is not implemented correctly
      dataModelMatrix[index][4] = false;

      value = apiHandle.LMSGetValue(name);
      

      err = apiHandle.LMSGetLastError();
      

      if(err != _NoError)
      {
         if ( err == _NotImplementedError)
         {
            if(dataModelMatrix[index][2] == true) // mandatory element
            {
               logMsg += " for <b>Mandatory</b> element resulted in the " +
                  "following error: " + doLMSGetErrorString(err);
               allMandatory = false;
               writeLogEntry(_FAILED, logMsg);
            }
            else   // optional element
            {
               logMsg += " for <b>Optional</b> element resulted in the " +
                  "following error: " + doLMSGetErrorString(err);
               allOptional = false;
               writeLogEntry(_WARNING, logMsg);
            }
         }
         else
         {
            // log the error... don't stop the test... assume we can recover
            logMsg += " resulted in the following error: ";
            logMsg += doLMSGetErrorString(err).toString();
            writeLogEntry(_WARNING, logMsg); // KEEP GOING! Not necessarily non-conformant...
            return;
         }
         
         return "";
      }
      else
      {
         // a value was returned with no error - so verify the return type 
         logMsg += "returned";
         if(lmsRTEApplet.verifyElementType(name, value) != cmiBooleanTrue)
         {
            logMsg += " a value that is NOT of the correct datatype:  ";
            logMsg += "&quot;" + value.toString() + "&quot;";
            writeLogEntry(_FAILED, logMsg);
            if(dataModelMatrix[index][2] == true) // mandatory element
            {
               allMandatory = false;
            }
            else   // optional element
            {
               allOptional = false;
            }
            
            return "";
         }
         else // type IS valid
         {

            logMsg += ":  &quot;" + value.toString() + "&quot;";
            if(dataModelMatrix[index][2] != true)
            {
               someOptional = true;
            }
            // element is implemented correctly
            dataModelMatrix[index][4] = true;
            writeLogEntry(_PASSED, logMsg);

            return value.toString();
         }
      }
   }




   /*******************************************************************************
   ** Function testSetValue(name, value) 
   ** Inputs:  name - string representing the cmi data model defined category or element
   **          value - the value that the named element or category will be assigned
   ** Return:  None
   **
   ** Description:
   ** Wraps the call to the LMS LMSSetValue method
   **
   *******************************************************************************/
   function testSetValue(name, value, index) 
   {

      // handle only the writeable data model elements
      if(dataModelMatrix[index][1] == _R)
      {
         return;
      }

      var logMsg =  "LMSSetValue(" +name+ ", &quot;"+ value+"&quot;)";
      var result = apiHandle.LMSSetValue(name, value);
      if(result != cmiBooleanTrue)
      {
         var err = apiHandle.LMSGetLastError();
         if(err != _NoError)
         {
            if(err == _NotImplementedError)
            {
               if(dataModelMatrix[index][2] == true) // mandatory
               {
                  logMsg += " for <b>Mandatory</b> element resulted in the " +
                     "following error: ";
                  allMandatory = false;

               /***************************************************************
               ***************************************************************/
               alert("Logging failure for Mandatory DM elem...");
               /***************************************************************
               ***************************************************************/

                  writeLogEntry(_FAILED, logMsg);
               }
               else
               {
                  logMsg += " for <b>Optional</b> element resulted in the " +
                     "following error: ";
                  allOptional = false;
                  writeLogEntry(_WARNING, logMsg);
               }
               return;

            }
            else
            {
               // log the error... don't stop the test... assume we can recover
               logMsg += " resulted in the following error: ";
               logMsg += doLMSGetErrorString(err).toString();
               writeLogEntry(_WARNING, logMsg); // KEEP GOING! Not necessarily non-conformant...
               return;
            }
         }
      }
      else
      {
         if(dataModelMatrix[index][2] != true) // optional element
         {
            // Some Optional (at least one) is conformant
            someOptional = true;
         }
      }

      // element is implemented correctly
      dataModelMatrix[index][4] = true;
      logMsg += " succeeded";
      writeLogEntry(_PASSED, logMsg);

      return;
   }

   
   /*******************************************************************************
   ** Function doLMSSetErroneousValue(name, value) 
   ** Inputs:  name - string representing the data model category or element
   **          value - the value that the element or category will be assigned
   ** Return:  None
   **
   ** Description:  Handles attempts to set data model elements with invalid values
   ** 
   **
   *******************************************************************************/
   
   function doLMSSetErroneousValue( name, value)
   {

      var result = apiHandle.LMSSetValue(name, value);
      var logMsg =  "LMSSetValue(" +name+ ", &quot;"+ value+"&quot;)";

      var err = apiHandle.LMSGetLastError();
      if (err != _NoError)
      {
         // This is what we hope happens...
         logMsg += " CORRECTLY resulted in the following error: ";
         logMsg += doLMSGetErrorString(err).toString();

         writeLogEntry(_PASSED, logMsg);
      }
      else
      {
         logMsg += " should NOT have succeeded due to an invalid value datatype but appears to have succeeded anyway.";
         writeLogEntry(_WARNING, logMsg);
      }
   }

   /*******************************************************************************
   ** function compareReadWriteValues(readVal, index)
   ** inputs:  readVal - value read from the LMS
   **          index - dataModelMatrix index of element
   ** outputs: none
   **
   ** purpose:
   ** Determines if the value passed back from the LMS is the same as the value 
   ** previously set by the SCO.
   *******************************************************************************/
   function compareReadWriteValues(readVal, index)
   {
      // check - only if the element is implemented correctly
      if(dataModelMatrix[index][4] == true)
      {
         if(dataModelMatrix[index][3] != readVal)
         {
            var logMsg = "The LMS returned a value that is different that the ";
            logMsg += "previously set value for ";


            if(dataModelMatrix[index][2] == true) // mandatory element
            {
               logMsg += " <b>Mandatory</b> element ";
               allMandatory = false;
            }
            else   // optional element
            {
               logMsg += " <b>Optional</b> element ";
               allOptional = false;
            }
            logMsg += dataModelMatrix[index][0];
            logMsg += "<br>Expected value: &quot;" + dataModelMatrix[index][3];
            logMsg += "&quot;<br>LMS Returned: &quot;" + readVal;
            logMsg += "&quot;";
            writeLogEntry(_FAILED, logMsg);
         }
      }

      return;
   }
   
   
   /*******************************************************************************
   ** function setDMStatus()
   ** inputs:  none
   ** outputs: none
   **
   ** purpose:
   ** Persists the data model conformance state values after a SCO is done testing
   ** data model elements
   *******************************************************************************/
   function setDMStatus()
   {
      if(someOptional == true)
      {
         lmsRTEApplet.setDMSomeOptional(true);
      }

      if(allOptional == false)
      {
         lmsRTEApplet.setDMAllOptional(false);
      }

      if(allMandatory == false)
      {
         lmsRTEApplet.setDMMandatory(false);
      }
   }

