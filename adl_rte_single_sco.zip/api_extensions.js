//***********************************************
//
// File Name: api_extensions.js
//
// Last Modified: Thu April 11 2002
//
// Description: Docent extensions to support AICC/SCORM courseware construction
// If a lesson is installed a different web server than the LMS web server,
// then the lesson, will need to include this file and then make 
// the following call to embed the API adapter in the lesson window.
//
// embedAPIAdapter() will embed API adapter applet in specified window.
//
// Lesson should use a frameset to store theAPI adapter in a hidden frame
// which will remain available for the duration of the lesson.  In that way,
// the frame source holding the lesson content can change while the hidden
// frame remains unchanged.
  
// Parameters Required on the Request: none.
//
//***********************************************
//
//                                  NOTICE
//
// This work is PROPRIETARY to Docent, Inc. and is protected
// under Federal Law as an unpublished Copyrighted work and under State
// Law as a Trade Secret.
//
// "U.S. Government End Users.  This software product, including its related
// documentation, is a "commercial item," as that term is defined at 48 C.F.R.
// 2.101 (Oct. 1995), consisting of "commercial computer software" and
// "commercial computer software documentation," as such terms are used in 48
// C.F.R. 12.212 (Sept. 1995) and is provided to the U.S. Government only as a
// commercial end item.  Consistent with 48 C.F.R. 12.212 and 48 C.F.R.
// 227.7202-1 through 227.7202-4 (June 1995), all U.S. Government End Users
// acquire the software product, including its related documentation, with only
// those rights set forth herein."
//
//
//                            Docent, Inc.
//                        2444 Charleston Drive
//                       Mountain View, CA 94043
//                            (650) 934-9500
//
//***********************************************

//---------------Docent extensions to support cross-domain scripting -------//

// Parse query string and return as hash of parmeter/value pairs
function parseQueryString(url)
{
    var hash = {};
    var params = url.substr(url.indexOf("?") + 1).split("&");
    // store key/value pairs extracted from url in QueryString object
    for (var i=0; i < params.length; i++)
    {
        var pair = params[i].split("=");
        var key = unescape(pair[0]).toLowerCase();
        var value = unescape(pair[1]);
        // store multiple or single values as a comma-delimited list
        var values = hash[key];
        if (!values) 
            hash[key] = value;
        else
            values += "," + value;
    }
    return hash;   
}

// Parse url and return a  property hash 
// { uri:, protocol:, server:, port:, relativeUrl:, queryString:}.	
// Default url is urlBase.
function parseURL(url)
{
    var results = url.match(/^((http[s]?):\/\/([^\/^:]+)(:([0-9]+))?\/?([^?]*))\??(.*)/i);
    if (results == null)
        return {};
    var properties = {};
    properties.uri = results[1];
    properties.protocol = results[2];
    properties.server = results[3];
    // if port is not explicitly specified, set port to 80
    properties.port = results[5] && results[5] != "" ? Number(results[5]) : 80;
    properties.relativeUrl = results[6] || "";
    properties.queryString = results[7] || "";
    return properties; 
}

// return http://server part of aicc_url
function getWebServer(aicc_url)
{
    var urlProps = parseURL(aicc_url);
    // if protocol is omitted, prepend it
    if (!urlProps.protocol)
        urlProps = parseURL("http://" + aicc_url);
    var url = urlProps.protocol + "://" + urlProps.server;
    if (urlProps.port != 80)
        url += ":" + urlProps.port;
    return url;
}

// return subdomain of server
function getSubDomain(server)
{
    return server.substr(server.indexOf(".") + 1);
}

// Embed API adapter in current window. 
//
// Parameters
//   lessonLaunchWindow :  (optional) current window by default. 
//                         Lesson launch window.
//   callback           :  (optional) callback invoked after API Adatper is loaded. 
//                         see initAPI() for a detailed explanation of how and when 
//                         to use this parameter. 
function embedAPIAdapter(lessonLaunchWindow, callback)
{
    lessonLaunchWindow == lessonLaunchWindow || window;

    // If API already initialized, skip 
    if (lessonLaunchWindow.API) {
        return;
    }

    // Embed API adapter
    var params = parseQueryString(lessonLaunchWindow.location.search);

    document.write('<APPLET code="org.adl.lms.client.DocentAPIAdapterApplet.class"\n');
    document.write('archive="apiadapter.jar"\n');
    document.write('codebase="' + params.codebase + '" src="' + params.codebase + '"');
    document.write('\nheight=0 id=API name=API width=0\n');
    document.write('MAYSCRIPT="true">\n');
    document.write('<param name="debug" value="false">\n');
    document.write('<param name="autoLessonSequencingOn" value="false">\n');
    // if callback defined, define callback parameter
    if (callback != null)
        document.write('<param name="callback" value="' + callback + '">\n');
    document.write('<param name=aicc_sid value="' + params.aicc_sid +'">\n'); 
    document.write('<param name=aicc_url value="' + params.aicc_url +'">\n'); 
    document.write('</APPLET>\n');
}
