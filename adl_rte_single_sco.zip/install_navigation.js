//***********************************************
//
// File Name: navigation.js
//
// Last Modified: Thu Apr 11
//
// Description: Docent extensions to support inter-lesson navigation
  
// Parameters Required on the Request: none.
//
//***********************************************
//
//                                  NOTICE
//
// This work is PROPRIETARY to Docent, Inc. and is protected
// under Federal Law as an unpublished Copyrighted work and under State
// Law as a Trade Secret.
//
// "U.S. Government End Users.  This software product, including its related
// documentation, is a "commercial item," as that term is defined at 48 C.F.R.
// 2.101 (Oct. 1995), consisting of "commercial computer software" and
// "commercial computer software documentation," as such terms are used in 48
// C.F.R. 12.212 (Sept. 1995) and is provided to the U.S. Government only as a
// commercial end item.  Consistent with 48 C.F.R. 12.212 and 48 C.F.R.
// 227.7202-1 through 227.7202-4 (June 1995), all U.S. Government End Users
// acquire the software product, including its related documentation, with only
// those rights set forth herein."
//
//
//                            Docent, Inc.
//                        2444 Charleston Drive
//                       Mountain View, CA 94043
//                            (650) 934-9500
//
//***********************************************

//---------------Docent extensions to support navigation -------//
var nav = window.parent.API_extensions;
if (nav) 
    cst = nav.gSCOCourseStructure;

function onNext()
{
    if (nav) {
        nav.changeSCOContent(cst.getNextSCO(), window);
    }
}

function onPrev()
{
    if (nav) {
        nav.changeSCOContent(cst.getPreviousSCO(), window);
    }
}

// Dynamic button generation based on current location in course
function installNavigationButtons()
{
    if (!nav || !cst)
        return;
    var prevLesson = cst.getPreviousSCO();
    var nextLesson = cst.getNextSCO();

    if (prevLesson || nextLesson) {
        document.write('<form method=POST action=""><table><tr>');
        if (prevLesson) {
            document.write('<td><INPUT TYPE=BUTTON OnClick="onPrev();" VALUE="Previous"></td>');
        }
        if (nextLesson) {
            document.write('<td><INPUT TYPE=BUTTON OnClick="onNext();" VALUE="Next"></td>');
        }
        document.write("</tr></table></form>");
    }
}
